package com.cognizant.ecommerce.exception;

public class AnalyticsReportGenerationException extends RuntimeException {
    public AnalyticsReportGenerationException(String message) {
        super(message);
    }
}

