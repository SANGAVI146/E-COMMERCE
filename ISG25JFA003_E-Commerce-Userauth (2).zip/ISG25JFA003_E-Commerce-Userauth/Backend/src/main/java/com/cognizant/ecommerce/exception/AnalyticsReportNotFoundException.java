package com.cognizant.ecommerce.exception;

public class AnalyticsReportNotFoundException extends RuntimeException {
  public AnalyticsReportNotFoundException(String message) {
    super(message);
  }
}
