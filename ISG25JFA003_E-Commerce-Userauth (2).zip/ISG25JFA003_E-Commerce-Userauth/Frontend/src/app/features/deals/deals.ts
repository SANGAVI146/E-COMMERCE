import { Component } from '@angular/core';

@Component({
  selector: 'app-deals',
  imports: [],
  templateUrl: './deals.html',
  styleUrl: './deals.scss'
})
export class Deals {

}
