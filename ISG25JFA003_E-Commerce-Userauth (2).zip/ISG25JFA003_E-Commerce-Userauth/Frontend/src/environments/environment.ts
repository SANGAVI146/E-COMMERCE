export const environment = {
  production: false,
  //apiUrl: 'http://localhost:8080/api/v1',
  razorpayKey: 'rzp_test_RXBQvhsOhZ3q7p', // Replace with your actual Razorpay key (rzp_test_xxx or rzp_live_xxx)
};