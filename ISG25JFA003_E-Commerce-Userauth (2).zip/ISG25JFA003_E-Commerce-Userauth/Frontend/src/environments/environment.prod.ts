export const environment = {
  production: true,
  //apiUrl: 'http://localhost:8080/api/v1', // Update with production URL when deploying
  razorpayKey: 'rzp_test_RXBQvhsOhZ3q7p' // Replace with your production Razorpay key (rzp_live_xxx)
};